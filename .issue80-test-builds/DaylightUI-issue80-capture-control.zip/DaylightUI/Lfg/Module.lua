-- Registers the group finder window with the core. It lives in the core addon and is
-- switched by the "enabled" setting, from the options or either window (Lfg.swap).

local _, DUI = ...
DUI.Lfg = DUI.Lfg or {}
local ns = DUI.Lfg

DUI:RegisterModule("GroupFinder", {
    label = "Group Finder",
    order = 129,
    section = "QoL", pageOrder = 133, windowCard = true,   -- a card on Extras > Windows
    ns = ns,
    parts = { "Data", "Rows", "Browse", "Listing", "Who", "Window" },
    defaults = ns.DEFAULTS,
    options = ns.OPTIONS,
    OnEnable = function(mod)
        ns.module = mod
        ns.Window.SwapInit()
        if ns.Window.Ours() then ns.Window.Build(mod) end
    end,
    OnSettingChanged = function()
        if ns.Window.swap then ns.Window.swap.Apply() end
        ns.Window.Apply()
    end,
    OnStyleChanged = function()
        if ns.Window then ns.Window.Apply() end
    end,
})
