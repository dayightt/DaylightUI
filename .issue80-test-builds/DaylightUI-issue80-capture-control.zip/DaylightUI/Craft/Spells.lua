-- The player's profession spells as a row of icons under the recipe list: each
-- profession's own (Tailoring, Smelting, Find Minerals, Fishing...), the same ones the
-- game's profession book shows (GetProfessionInfo numSpells from spellOffset, minus
-- passives and future spells). This window replaces that book, so this is where they
-- get dragged to an action bar. Drag picks one up, Shift-click links it. No click to
-- cast: a secure button here would lock the whole window in combat.

local _, DUI = ...
DUI.Craft = DUI.Craft or {}
local ns = DUI.Craft
local L = DUI.L
local Style = DUI.Style
local Win = DUI.Win

local Spells = {}
ns.Spells = Spells

Spells.ICON = 28      -- footer height, so the row lines up with the recipe buttons
Spells.GAP = 6
Spells.BORDER = 2     -- icon border, same as the spellbook
Spells.FOOT = 52      -- room under the list (matches Make.FOOT on the recipe side)

local WHITE = "Interface\\Buttons\\WHITE8X8"

local secret = DUI.IsSecret
local function num(v) return type(v) == "number" and not secret(v) and v or nil end

local function bank()
    return Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0
end

-- { { slot, bank, spellID, icon, name } } in the game's profession order.
function Spells.Read()
    local out = {}
    if type(GetProfessions) ~= "function" or type(GetProfessionInfo) ~= "function" then return out end
    if not (C_SpellBook and type(C_SpellBook.GetSpellBookItemInfo) == "function") then return out end
    local spell = Enum and Enum.SpellBookItemType and Enum.SpellBookItemType.Spell
    local list = { GetProfessions() }
    for i = 1, 7 do
        local idx = list[i]
        if idx then
            local _, _, _, _, n, offset = GetProfessionInfo(idx)
            n, offset = num(n), num(offset)
            for k = 1, (n and offset) and math.min(n, 2) or 0 do   -- the game's book shows two at most
                local slot = offset + k
                local info = C_SpellBook.GetSpellBookItemInfo(slot, bank())
                if type(info) == "table" and not info.isPassive and (spell == nil or info.itemType == spell) then
                    out[#out + 1] = { slot = slot, bank = bank(), spellID = num(info.spellID),
                                      icon = info.iconID, name = info.name }
                end
            end
        end
    end
    return out
end

-- Icon

local function makeIcon(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(Spells.ICON, Spells.ICON)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    b.well = CreateFrame("Frame", nil, b)
    b.well:SetAllPoints(b)
    Style.Shell(b.well, { borderPx = Spells.BORDER, noBevel = true })
    b.icon = b.well:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints(b.well)
    Style.CropIcon(b.icon)
    b.hover = b.well:CreateTexture(nil, "OVERLAY")
    b.hover:SetTexture(WHITE)
    b.hover:SetAllPoints(b.icon)
    b.hover:SetBlendMode("ADD")
    b.hover:SetVertexColor(1, 1, 1, 0.18)
    b.hover:Hide()
    b:SetScript("OnEnter", function(self) Spells.Enter(self) end)
    b:SetScript("OnLeave", function(self) Spells.Leave(self) end)
    b:SetScript("OnDragStart", function(self) Spells.Drag(self) end)
    b:SetScript("OnClick", function(self, button) Spells.Modified(self, button) end)
    return b
end

function Spells.Enter(b)
    local s = b.spell
    if not s then return end
    Win.Parts.Light(b.hover, true)
    local tip = GameTooltip
    if not tip then return end
    tip:SetOwner(b, "ANCHOR_RIGHT")
    if type(tip.SetSpellBookItem) == "function" then tip:SetSpellBookItem(s.slot, s.bank)
    elseif s.spellID and type(tip.SetSpellByID) == "function" then tip:SetSpellByID(s.spellID) end
    if InCombatLockdown() then
        local w = Style.INK.WARN
        tip:AddLine(L["Clicking and dragging work out of combat."], w[1], w[2], w[3], true)
    else
        local r, g, bl = Style.Accent()
        tip:AddLine(L["Drag it to an action bar."], r, g, bl, true)
    end
    tip:Show()
end

function Spells.Leave(b)
    Win.Parts.Light(b.hover, false)
    if GameTooltip and GameTooltip:IsOwned(b) then GameTooltip:Hide() end
end

-- The game blocks picking up spells from addon code in combat.
function Spells.Drag(b)
    local s = b.spell
    if not s or InCombatLockdown() then return end
    C_SpellBook.PickupSpellBookItem(s.slot, s.bank)
end

-- Shift-click links it, trade skill link first, like the game's book
-- (ProfessionSpellButtonMixin:OnModifiedClick).
function Spells.Modified(b, button)
    local s = b.spell
    if not s or button ~= "LeftButton" or not IsModifiedClick("CHATLINK") then return end
    local insert = ChatFrameUtil and ChatFrameUtil.InsertLink or ChatEdit_InsertLink
    if type(insert) ~= "function" then return end
    local link = C_SpellBook.GetSpellBookItemTradeSkillLink and C_SpellBook.GetSpellBookItemTradeSkillLink(s.slot, s.bank)
    link = link or (C_SpellBook.GetSpellBookItemLink and C_SpellBook.GetSpellBookItemLink(s.slot, s.bank))
    if link then insert(link) end
end

-- The row

-- Under the list (pane), level with the recipe side's footer, with the same faint line
-- above it.
function Spells.Build(pane)
    local row = CreateFrame("Frame", nil, pane)
    row:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", Win.Parts.EDGE, 12)
    row:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", -Win.Parts.EDGE, 12)
    row:SetHeight(Spells.ICON)
    row.line = Win.Parts.Rule(row)
    row.line:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 10)
    row.line:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 10)
    -- A label before the icons, so it's clear they're spells to drag to a bar.
    row.label = Style.Text(row, Style.SIZE.small, "LEFT")
    row.label:SetPoint("LEFT", row, "LEFT", 0, 0)
    row.label:SetText(L["Abilities"])
    Style.InkText(row.label, "LABEL")
    row.icons = {}
    row.training = Spells.MakeTraining(row)
    row.skillup = Spells.MakeSkillUp(row)
    Spells.row = row
    DUI.RegisterEvent("SPELLS_CHANGED", function() if row:IsVisible() then Spells.Fill() end end)
    return row
end

-- Icons start after the label plus a gap. The label is measured now so a font or
-- language change moves the icons with it.
Spells.LABEL_GAP = 10
function Spells.Lead()
    local label = Spells.row and Spells.row.label
    local w = label and label:GetStringWidth()
    if type(w) ~= "number" or w <= 0 then return 0 end
    return math.ceil(w) + Spells.LABEL_GAP
end

-- What's Training puts its recipe list on a side tab of the game's profession
-- window, which this one covers. Its own floating window has the same list, so
-- the row links to that instead.
function Spells.Training()
    local A = C_AddOns
    if not (A and type(A.IsAddOnLoaded) == "function") or A.IsAddOnLoaded("WhatsTraining") ~= true then return nil end
    local open = SlashCmdList and SlashCmdList.WHATSTRAINING
    return type(open) == "function" and open or nil
end

function Spells.OpenTraining()
    local open = Spells.Training()
    if not open then return end
    local f = _G.WhatsTrainingFloatingFrame
    if not (type(f) == "table" and f:IsShown()) then pcall(open, "") end
    f = _G.WhatsTrainingFloatingFrame
    if type(f) == "table" and type(f.SetProfessionView) == "function" then pcall(f.SetProfessionView, f, true) end
end

function Spells.MakeTraining(row)
    local link = DUI.Widgets.Link(row)
    link.SetLabel(L["What's Training"])
    link:SetPoint("RIGHT", row, "RIGHT", 0, 0)
    link:SetScript("OnClick", function() Spells.OpenTraining() end)
    link:Hide()
    return link
end

-- SkillUp Forever's numbers and route live on the game's window, so its link
-- hands that window back (Craft.HandBack).
function Spells.SkillUp()
    local A = C_AddOns
    return A and type(A.IsAddOnLoaded) == "function" and A.IsAddOnLoaded("SkillUpForever") == true or false
end

function Spells.MakeSkillUp(row)
    local link = DUI.Widgets.Link(row)
    link.SetLabel(L["SkillUp"])
    link:SetScript("OnClick", function() ns.Window.HandBack() end)
    link:HookScript("OnEnter", function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        DUI.Tips.Clear()
        DUI.Tips.Title(L["SkillUp Forever"])
        DUI.Tips.Text(L["Shows the game's profession window, where SkillUp Forever draws its skill-up chances, costs and route. Daylight UI's window comes back the next time you open a profession."])
        DUI.Tips.Hint(L["Click: switch to the game's window"])
        DUI.Tips.Flush(GameTooltip)
        GameTooltip:Show()
    end)
    link:HookScript("OnLeave", function(self)
        if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end)
    link:Hide()
    return link
end

-- As many as fit (Spells.Read rarely returns more than six).
function Spells.Fill()
    local row = Spells.row
    if not row then return end
    local list = Spells.Read()
    local w = row:GetWidth()
    if type(w) ~= "number" or w <= 0 then w = ns.List.W - 2 * Win.Parts.EDGE end
    local training = Spells.Training() ~= nil
    local skillup = Spells.SkillUp()
    row.training:SetShown(training)
    row.skillup:SetShown(skillup)
    -- Links sit at the row's right end, the icons get what's left.
    local right = 0
    for _, link in ipairs({ row.training, row.skillup }) do
        if link:IsShown() then
            link:ClearAllPoints()
            link:SetPoint("RIGHT", row, "RIGHT", -right, 0)
            local lw = link:GetWidth()
            right = right + ((type(lw) == "number" and lw > 0) and lw or 0) + Spells.LABEL_GAP
        end
    end
    w = w - right
    local lead = Spells.Lead()
    local fit = math.max(0, math.floor((w - lead + Spells.GAP) / (Spells.ICON + Spells.GAP)))
    for i = 1, math.max(#list, #row.icons) do
        local s = i <= fit and list[i] or nil
        local b = row.icons[i]
        if s and not b then
            b = makeIcon(row)
            row.icons[i] = b
        end
        if b then b:SetPoint("LEFT", row, "LEFT", lead + (i - 1) * (Spells.ICON + Spells.GAP), 0) end
        if b then
            b.spell = s
            if s then b.icon:SetTexture(s.icon) end
            b:SetShown(s ~= nil)
        end
    end
    row:SetShown(#list > 0 or training or skillup)
end

-- Lift-in pieces.
function Spells.Pieces()
    local out = {}
    for _, b in ipairs(Spells.row and Spells.row.icons or {}) do
        if b:IsShown() then out[#out + 1] = b end
    end
    for _, key in ipairs({ "training", "skillup" }) do
        local t = Spells.row and Spells.row[key]
        if t and t:IsShown() then out[#out + 1] = t end
    end
    return out
end
