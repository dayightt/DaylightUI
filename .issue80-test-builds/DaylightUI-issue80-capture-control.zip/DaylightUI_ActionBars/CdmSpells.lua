-- Made by tools/make_cdm_spells.py from talentsforever.com/data.json
-- (generated 2026-11-10), CC BY 4.0: https://talentsforever.com, see
-- CdmSpells-LICENSE.txt. Spell ids and two flags only, no tooltip text.
-- Don't edit by hand: run the tool again.
--
-- Per class token: one family per spell, every rank's id (rank 1 first);
-- cd = a cooldown over the global cooldown, aura = it puts up a buff or a
-- debuff, passive = a passive whose buff has a spell id of its own.
-- GROUP: buffs other classes put on you (class = whose).

local _, ns = ...

local S = {
    WARRIOR = {
        { 6673, 5242, 6192, 11549, 11550, 11551, 25289, aura = true }, -- Battle Shout
        { 18499, cd = true, aura = true }, -- Berserker Rage
        { 2687, cd = true, aura = true }, -- Bloodrage
        { 23881, 23892, 23893, 23894, cd = true, aura = true }, -- Bloodthirst
        { 1161, cd = true, aura = true }, -- Challenging Shout
        { 100, 6178, 11578, cd = true, aura = true }, -- Charge
        { 12809, cd = true, aura = true }, -- Concussion Blow
        { 12328, cd = true, aura = true }, -- Death Wish
        { 1160, 6190, 11554, 11555, 11556, aura = true }, -- Demoralizing Shout
        { 676, cd = true, aura = true }, -- Disarm
        { 1715, 7372, 7373, aura = true }, -- Hamstring
        { 20252, 20616, 20617, cd = true, aura = true }, -- Intercept
        { 5246, cd = true, aura = true }, -- Intimidating Shout
        { 12975, cd = true, aura = true }, -- Last Stand
        { 694, 7400, 7402, 20559, 20560, cd = true, aura = true }, -- Mocking Blow
        { 12294, 21551, 21552, 21553, cd = true, aura = true }, -- Mortal Strike
        { 7384, 7887, 11584, 11585, cd = true }, -- Overpower
        { 12323, aura = true }, -- Piercing Howl
        { 6552, 6554, cd = true, aura = true }, -- Pummel
        { 1329555, cd = true, aura = true }, -- Reckless Swings
        { 1719, cd = true }, -- Recklessness
        { 772, 6546, 6547, 6548, 11572, 11573, 11574, aura = true }, -- Rend
        { 20230, cd = true, aura = true }, -- Retaliation
        { 6572, 6574, 7379, 11600, 11601, 25288, cd = true }, -- Revenge
        { 72, 1671, 1672, cd = true, aura = true }, -- Shield Bash
        { 2565, cd = true, aura = true }, -- Shield Block
        { 23922, 23923, 23924, 23925, cd = true }, -- Shield Slam
        { 871, cd = true, aura = true }, -- Shield Wall
        { 1240193, 1464, 8820, 11604, 11605, cd = true }, -- Slam
        { 1310222, cd = true }, -- Spearing Strike
        { 7386, 7405, 8380, 11596, 11597, aura = true }, -- Sunder Armor
        { 12292, cd = true }, -- Sweeping Strikes
        { 355, cd = true }, -- Taunt
        { 6343, 8198, 8204, 8205, 11580, 11581, cd = true, aura = true }, -- Thunder Clap
        { 402927, cd = true }, -- Victory Rush
        { 1680, cd = true }, -- Whirlwind
    },
    PALADIN = {
        { 1044, cd = true, aura = true }, -- Blessing of Freedom
        { 20217, aura = true }, -- Blessing of Kings
        { 19740, 19834, 19835, 19836, 19837, 19838, 25291, aura = true }, -- Blessing of Might
        { 1022, 5599, 10278, cd = true, aura = true }, -- Blessing of Protection
        { 6940, 20729, aura = true }, -- Blessing of Sacrifice
        { 19742, 19850, 19852, 19853, 19854, 25290, aura = true }, -- Blessing of Wisdom
        { 26573, 20116, 20922, 20923, 20924, cd = true, aura = true }, -- Consecration
        { 20216, cd = true }, -- Divine Favor
        { 19752, cd = true, aura = true }, -- Divine Intervention
        { 498, 5573, cd = true, aura = true }, -- Divine Protection
        { 642, 1020, cd = true, aura = true }, -- Divine Shield
        { 879, 5614, 5615, 10312, 10313, 10314, cd = true }, -- Exorcism
        { 25898, aura = true }, -- Greater Blessing of Kings
        { 25782, 25916, aura = true }, -- Greater Blessing of Might
        { 25894, 25918, aura = true }, -- Greater Blessing of Wisdom
        { 853, 5588, 5589, 10308, cd = true, aura = true }, -- Hammer of Justice
        { 24275, 24274, 24239, cd = true }, -- Hammer of Wrath
        { 20925, 20927, 20928, 1239570, cd = true, aura = true }, -- Holy Shield
        { 1311606, 20473, 20929, 20930, cd = true }, -- Holy Shock
        { 679, 678, 1866, 680, 2495, 5569, 10332, 10333, cd = true }, -- Holy Strike
        { 2812, 10318, cd = true, aura = true }, -- Holy Wrath
        { 20271, cd = true }, -- Judgement
        { 633, 2800, 10310, cd = true }, -- Lay on Hands
        { 1310911, 1311590, 1311595, cd = true, aura = true }, -- Light's Vigil
        { 1328548, aura = true }, -- Oath of Light
        { 20066, cd = true, aura = true }, -- Repentance
        { 25780, aura = true }, -- Righteous Fury
        { 20375, 20915, 20918, 20919, 20920, aura = true }, -- Seal of Command
        { 1311649, 1311656, 20163, 20419, 20421, 20422, 20423, aura = true }, -- Seal of Fury
        { 20164, aura = true }, -- Seal of Justice
        { 20165, 20347, 20348, 20349, aura = true }, -- Seal of Light
        { 20154, 20287, 20288, 20289, 20290, 20291, 20292, 20293, aura = true }, -- Seal of Righteousness
        { 20166, 20356, 20357, aura = true }, -- Seal of Wisdom
        { 21082, 20162, 20305, 20306, 20307, 20308, aura = true }, -- Seal of the Crusader
        { 1310994, cd = true }, -- Swift Judgement
        { 1311015, cd = true, aura = true }, -- Templar's Bulwark
        { 2878, 5627, 10326, cd = true, aura = true }, -- Turn Undead
    },
    HUNTER = {
        { 19434, 20900, 20901, 20902, 20903, 20904, cd = true }, -- Aimed Shot
        { 3044, 14281, 14282, 14283, 14284, 14285, 14286, 14287, cd = true }, -- Arcane Shot
        { 5118, aura = true }, -- Aspect of the Cheetah
        { 13159, aura = true }, -- Aspect of the Pack
        { 19574, cd = true, aura = true }, -- Bestial Wrath
        { 17253, 17255, 17256, 17257, 17258, 17259, 17260, 17261, cd = true }, -- Bite
        { 7371, 26177, 26178, 26179, 26201, 27685, cd = true, aura = true }, -- Charge
        { 5116, cd = true, aura = true }, -- Concussive Shot
        { 19306, 1242634, 20909, 20910, cd = true, aura = true }, -- Counterattack
        { 1742, 1753, 1754, 1755, 1756, 16697, cd = true }, -- Cower
        { 23099, 23109, 23110, cd = true, aura = true }, -- Dash
        { 24423, 24577, 24578, 24579, cd = true, aura = true }, -- Demoralizing Screech
        { 19263, cd = true, aura = true }, -- Deterrence
        { 781, 14272, 14273, cd = true }, -- Disengage
        { 1264758, 1264927, 1264929, 1264930, 1264933, cd = true, aura = true }, -- Dismember
        { 20736, 14274, 15629, 15630, 15631, 15632, cd = true }, -- Distracting Shot
        { 23145, 23147, 23148, cd = true, aura = true }, -- Dive
        { 1265899, 1265901, 1265902, 1265903, 1265904, aura = true }, -- Dust Cloud
        { 6197, aura = true }, -- Eagle Eye
        { 1221404, cd = true, aura = true }, -- Enchanted Flare
        { 13813, 14316, 14317, cd = true, aura = true }, -- Explosive Trap
        { 1002, aura = true }, -- Eyes of the Beast
        { 5384, cd = true, aura = true }, -- Feign Death
        { 1543, cd = true, aura = true }, -- Flare
        { 1499, 14310, 14311, cd = true, aura = true }, -- Freezing Trap
        { 13809, cd = true, aura = true }, -- Frost Trap
        { 24604, 24605, 24603, 24597, cd = true, aura = true }, -- Furious Howl
        { 2649, 14916, 14917, 14918, 14919, 14920, 14921, cd = true }, -- Growl
        { 1130, 14323, 14324, 14325, aura = true }, -- Hunter's Mark
        { 13795, 14302, 14303, 14304, 14305, cd = true, aura = true }, -- Immolation Trap
        { 19577, cd = true, aura = true }, -- Intimidation
        { 24118, 24119, 24120, 1299332, aura = true }, -- Lacerate
        { 136, 3111, 3661, 3662, 13542, 13543, 13544, aura = true }, -- Mend Pet
        { 1265054, 1265055, 1265056, 1265057, 1265058, cd = true, aura = true }, -- Mine!
        { 1495, 14269, 14270, 14271, cd = true }, -- Mongoose Bite
        { 2643, cd = true }, -- Multi-Shot
        { 1264735, 1264736, 1264739, 1264741, 1264742, cd = true, aura = true }, -- Pinch
        { 24450, 24452, 24453, cd = true }, -- Prowl
        { 3045, cd = true, aura = true }, -- Rapid Fire
        { 2973, 14260, 14261, 14262, 14263, 14264, 14265, 14266, cd = true }, -- Raptor Strike
        { 1265065, 1265066, 1265067, 1265068, 1265069, cd = true, aura = true }, -- Savage Rend
        { 1513, 14326, 14327, cd = true, aura = true }, -- Scare Beast
        { 19503, cd = true, aura = true }, -- Scatter Shot
        { 24640, 24583, 24586, 24587, cd = true, aura = true }, -- Scorpid Poison
        { 3043, aura = true }, -- Scorpid Sting
        { 1978, 13549, 13550, 13551, 13552, 13553, 13554, 13555, 25295, aura = true }, -- Serpent Sting
        { 26064, cd = true, aura = true }, -- Shell Shield
        { 1310687, 1310785, 1310786, cd = true, aura = true }, -- Sniper Shot
        { 1264478, 1264479, 1264480, 1264481, 1264482, cd = true, aura = true }, -- Sonic Blast
        { 1317257, cd = true, aura = true }, -- Strider Kick
        { 1293241, 1293525, 1293526, 1293527, cd = true, aura = true }, -- Summon Hawk
        { 1264494, 1264497, 1264498, 1264501, 1264502, cd = true }, -- Swipe
        { 1515, aura = true }, -- Tame Beast
        { 1265038, 1265039, 1265040, 1265041, 1265042, cd = true, aura = true }, -- Tendon Rip
        { 26090, 26187, 26188, 1264455, cd = true }, -- Thunderstomp
        { 19801, cd = true }, -- Tranquilizing Shot
        { 1310612, cd = true, aura = true }, -- Trickster's Dance
        { 1299346, 1299348, 19506, 20905, 20906, aura = true }, -- Trueshot Aura
        { 3034, 14279, 14280, cd = true, aura = true }, -- Viper Sting
        { 1510, 14294, 14295, aura = true }, -- Volley
        { 1265843, 1265878, 1265880, 1265881, 1265883, cd = true, aura = true }, -- Web
        { 2974, 14267, 14268, aura = true }, -- Wing Clip
    },
    ROGUE = {
        { 13750, cd = true, aura = true }, -- Adrenaline Rush
        { 13877, cd = true, aura = true }, -- Blade Flurry
        { 2094, cd = true, aura = true }, -- Blind
        { 1833, aura = true }, -- Cheap Shot
        { 14177, cd = true }, -- Cold Blood
        { 3420, 3421, aura = true }, -- Crippling Poison
        { 2835, 2837, 11357, 11358, 25347, aura = true }, -- Deadly Poison
        { 1316709, 1325756, 1325757, 1325758, cd = true }, -- Death Mark
        { 1725, cd = true }, -- Distract
        { 5277, cd = true, aura = true }, -- Evasion
        { 8647, 8649, 8650, 11197, 11198, aura = true }, -- Expose Armor
        { 1966, 6768, 8637, 11303, 25302, cd = true }, -- Feint
        { 703, 8631, 8632, 8633, 11289, 11290, aura = true }, -- Garrote
        { 14278, cd = true, aura = true }, -- Ghostly Strike
        { 1776, 1777, 8629, 11285, 11286, cd = true, aura = true }, -- Gouge
        { 16511, aura = true }, -- Hemorrhage
        { 1766, 1767, 1768, 1769, cd = true, aura = true }, -- Kick
        { 408, 8643, cd = true, aura = true }, -- Kidney Shot
        { 5763, 8694, 11400, aura = true }, -- Mind-numbing Poison
        { 1328825, aura = true, passive = true }, -- Poised
        { 14183, cd = true }, -- Premeditation
        { 14185, cd = true }, -- Preparation
        { 14251, cd = true, aura = true }, -- Riposte
        { 1943, 8639, 8640, 11273, 11274, 11275, aura = true }, -- Rupture
        { 6770, 2070, 11297, aura = true }, -- Sap
        { 1329283, 1329549, cd = true }, -- Shank
        { 5171, 6774, aura = true }, -- Slice and Dice
        { 2983, 8696, 11305, cd = true, aura = true }, -- Sprint
        { 1784, 1785, 1786, 1787, cd = true }, -- Stealth
        { 1856, 1857, cd = true, aura = true }, -- Vanish
        { 13220, 13228, 13229, 13230, aura = true }, -- Wound Poison
    },
    PRIEST = {
        { 552, aura = true }, -- Abolish Disease
        { 1277331, 1277332, 1277333, 1277334, 1277335, cd = true, aura = true }, -- Chastise
        { 1277455, cd = true, aura = true }, -- Confounding Flash
        { 1277462, 1277634, 1277638, 1277639, 1277640, cd = true, aura = true }, -- Contingency Plan
        { 1277324, 1277325, 1277326, 1277327, 1277328, cd = true, aura = true }, -- Dark Sacrifice
        { 13908, 19236, 19238, 19240, 19241, 19242, 19243, cd = true }, -- Desperate Prayer
        { 2944, 19276, 19277, 19278, 19279, 19280, cd = true, aura = true }, -- Devouring Plague
        { 1277370, 1277371, 1277372, 1277374, 1277376, 1277377, 1277378, cd = true }, -- Divine Grace
        { 14752, 14818, 14819, 27841, aura = true }, -- Divine Spirit
        { 2651, cd = true, aura = true }, -- Elune's Grace
        { 586, 9578, 9579, 9592, 10941, 10942, cd = true, aura = true }, -- Fade
        { 6346, cd = true, aura = true }, -- Fear Ward
        { 13896, 19271, 19273, 19274, 19275, cd = true, aura = true }, -- Feedback
        { 9035, 19281, 19282, 19283, 19284, 19285, aura = true }, -- Hex of Weakness
        { 14914, 15262, 15263, 15264, 15265, 15266, 15267, 15261, aura = true }, -- Holy Fire
        { 588, 7128, 602, 1006, 10951, 10952, aura = true }, -- Inner Fire
        { 14751, cd = true }, -- Inner Focus
        { 1706, aura = true }, -- Levitate
        { 8092, 8102, 8103, 8104, 8105, 8106, 10945, 10946, 10947, cd = true }, -- Mind Blast
        { 15407, 17311, 17312, 17313, 17314, 18807, aura = true }, -- Mind Flay
        { 453, 8192, 10953, aura = true }, -- Mind Soothe
        { 2096, 10909, aura = true }, -- Mind Vision
        { 402174, 1240720, 1240721, 1316995, cd = true, aura = true }, -- Penance
        { 10060, cd = true, aura = true }, -- Power Infusion
        { 1243, 1244, 1245, 2791, 10937, 10938, aura = true }, -- Power Word: Fortitude
        { 17, 592, 600, 3747, 6065, 6066, 10898, 10899, 10900, 10901, cd = true, aura = true }, -- Power Word: Shield
        { 21562, 21564, aura = true }, -- Prayer of Fortitude
        { 401859, 1240826, 1240827, cd = true, aura = true }, -- Prayer of Mending
        { 27683, aura = true }, -- Prayer of Shadow Protection
        { 27681, aura = true }, -- Prayer of Spirit
        { 8122, 8124, 10888, 10890, cd = true, aura = true }, -- Psychic Scream
        { 139, 6074, 6075, 6076, 6077, 6078, 10927, 10928, 10929, 25315, aura = true }, -- Renew
        { 9484, 9485, 10955, aura = true }, -- Shackle Undead
        { 976, 10957, 10958, aura = true }, -- Shadow Protection
        { 1309595, 1309633, 1309635, 1309636, cd = true }, -- Shadow Word: Death
        { 589, 594, 970, 992, 2767, 10892, 10893, 10894, aura = true }, -- Shadow Word: Pain
        { 18137, 19308, 19309, 19310, 19311, 19312, aura = true }, -- Shadowguard
        { 15487, cd = true, aura = true }, -- Silence
        { 10797, 19296, 19299, 19302, 19303, 19304, 19305, cd = true, aura = true }, -- Starshards
        { 2652, 19261, 19262, 19264, 19265, 19266, aura = true }, -- Touch of Weakness
        { 15286, cd = true, aura = true }, -- Vampiric Embrace
    },
    SHAMAN = {
        { 556, cd = true }, -- Astral Recall
        { 421, 930, 2860, 10605, cd = true }, -- Chain Lightning
        { 8170, aura = true }, -- Disease Cleansing Totem
        { 8042, 8044, 8045, 8046, 10412, 10413, 10414, cd = true, aura = true }, -- Earth Shock
        { 2484, cd = true, aura = true }, -- Earthbind Totem
        { 6196, aura = true }, -- Far Sight
        { 408341, 408342, 408343, 408344, 408345, cd = true }, -- Fire Nova
        { 8184, 10537, 10538, aura = true }, -- Fire Resistance Totem
        { 8050, 8052, 8053, 10447, 10448, 29228, cd = true, aura = true }, -- Flame Shock
        { 8227, 8249, 10526, 16387, aura = true }, -- Flametongue Totem
        { 8181, 10478, 10479, aura = true }, -- Frost Resistance Totem
        { 8056, 8058, 10472, 10473, cd = true, aura = true }, -- Frost Shock
        { 8033, 8038, 10456, 16355, 16356, aura = true }, -- Frostbrand Weapon
        { 8835, 10627, 25359, aura = true }, -- Grace of Air Totem
        { 8177, cd = true, aura = true }, -- Grounding Totem
        { 5394, 6375, 6377, 10462, 10463, aura = true }, -- Healing Stream Totem
        { 16166, cd = true, aura = true }, -- Lightning Mastery
        { 324, 325, 905, 945, 8134, 10431, 10432, aura = true }, -- Lightning Shield
        { 8190, 10585, 10586, 10587, aura = true }, -- Magma Totem
        { 5675, 10495, 10496, 10497, aura = true }, -- Mana Spring Totem
        { 16190, 17354, 17359, 1325256, cd = true, aura = true }, -- Mana Tide Totem
        { 10595, 10600, 10601, aura = true }, -- Nature Resistance Totem
        { 16188, cd = true }, -- Nature's Swiftness
        { 8166, aura = true }, -- Poison Cleansing Totem
        { 425336, cd = true, aura = true }, -- Rage of the Farseer
        { 20608, cd = true }, -- Reincarnation
        { 408521, 1239242, 1239243, cd = true, aura = true }, -- Riptide
        { 3599, 6363, 6364, 6365, 10437, 10438, aura = true }, -- Searing Totem
        { 6495, aura = true }, -- Sentry Totem
        { 5730, 6390, 6391, 6392, 10427, 10428, cd = true, aura = true }, -- Stoneclaw Totem
        { 8071, 8154, 8155, 10406, 10407, 10408, aura = true }, -- Stoneskin Totem
        { 17364, cd = true, aura = true }, -- Stormstrike
        { 8075, 8160, 8161, 10442, 25361, aura = true }, -- Strength of Earth Totem
        { 437009, cd = true }, -- Totemic Call
        { 8143, aura = true }, -- Tremor Totem
        { 131, aura = true }, -- Water Breathing
        { 408510, aura = true }, -- Water Shield
        { 546, aura = true }, -- Water Walking
        { 8512, 10613, 10614, aura = true }, -- Windfury Totem
        { 15107, 15111, 15112, aura = true }, -- Windwall Totem
    },
    MAGE = {
        { 1008, 8455, 10169, 10170, aura = true }, -- Amplify Magic
        { 400574, 1239696, 1239697, 1239699, 1239700, aura = true }, -- Arcane Blast
        { 23028, aura = true }, -- Arcane Brilliance
        { 1459, 1460, 1461, 10156, 10157, aura = true }, -- Arcane Intellect
        { 5143, 5144, 5145, 8416, 8417, 10211, 10212, 25345, aura = true }, -- Arcane Missiles
        { 12042, cd = true }, -- Arcane Power
        { 1326079, 1326080, 1326081, 1326082, cd = true }, -- Arcane Wrath
        { 11113, 13018, 13019, 13020, 13021, cd = true, aura = true }, -- Blast Wave
        { 1953, cd = true }, -- Blink
        { 10, 6141, 8427, 10185, 10186, 10187, aura = true }, -- Blizzard
        { 12472, cd = true }, -- Cold Snap
        { 11129, cd = true }, -- Combustion
        { 120, 8492, 10159, 10160, cd = true, aura = true }, -- Cone of Cold
        { 2139, cd = true, aura = true }, -- Counterspell
        { 604, 8450, 8451, 10173, 10174, aura = true }, -- Dampen Magic
        { 12051, cd = true, aura = true }, -- Evocation
        { 2136, 2137, 2138, 8412, 8413, 10197, 10199, cd = true }, -- Fire Blast
        { 543, 8457, 8458, 10223, 10225, cd = true, aura = true }, -- Fire Ward
        { 133, 143, 145, 3140, 8400, 8401, 8402, 10148, 10149, 10150, 10151, 25306, aura = true }, -- Fireball
        { 2120, 2121, 8422, 8423, 10215, 10216, aura = true }, -- Flamestrike
        { 168, 7300, 7301, aura = true }, -- Frost Armor
        { 122, 865, 6131, 10230, cd = true, aura = true }, -- Frost Nova
        { 6143, 8461, 8462, 10177, 28609, cd = true, aura = true }, -- Frost Ward
        { 116, 205, 837, 7322, 8406, 8407, 8408, 10179, 10180, 10181, 25304, aura = true }, -- Frostbolt
        { 401502, 1237312, 1237313, aura = true }, -- Frostfire Bolt
        { 7302, 7320, 10219, 10220, aura = true }, -- Ice Armor
        { 11426, 13031, 13032, 13033, cd = true, aura = true }, -- Ice Barrier
        { 11958, cd = true, aura = true }, -- Ice Block
        { 1312002, 400640, 1240044, 1240045, 1240046, 1240047, cd = true }, -- Ice Lance
        { 6117, 22782, 22783, aura = true }, -- Mage Armor
        { 1463, 8494, 8495, 10191, 10192, 10193, aura = true }, -- Mana Shield
        { 28271, 28272, 118, 12824, 12825, 12826, aura = true }, -- Polymorph
        { 11419, cd = true }, -- Portal: Darnassus
        { 11416, cd = true }, -- Portal: Ironforge
        { 11417, cd = true }, -- Portal: Orgrimmar
        { 10059, cd = true }, -- Portal: Stormwind
        { 11420, cd = true }, -- Portal: Thunder Bluff
        { 11418, cd = true }, -- Portal: Undercity
        { 12043, cd = true }, -- Presence of Mind
        { 11366, 12505, 12522, 12523, 12524, 12525, 12526, 18809, aura = true }, -- Pyroblast
        { 130, aura = true }, -- Slow Fall
    },
    WARLOCK = {
        { 18288, cd = true, aura = true }, -- Amplify Curse
        { 980, 1014, 6217, 11711, 11712, 11713, aura = true }, -- Bane of Agony
        { 603, cd = true }, -- Bane of Doom
        { 1225228, aura = true }, -- Bane of Havoc
        { 710, 18647, aura = true }, -- Banish
        { 1293817, 1293818, 17962, 18930, 18931, 18932, cd = true }, -- Conflagrate
        { 17767, 17850, 17851, 17852, 17853, 17854, aura = true }, -- Consume Shadows
        { 172, 6222, 6223, 7648, 11671, 11672, 25311, aura = true }, -- Corruption
        { 18223, aura = true }, -- Curse of Exhaustion
        { 704, 7658, 7659, 11717, aura = true }, -- Curse of Recklessness
        { 1714, 11719, aura = true }, -- Curse of Tongues
        { 702, 1108, 6205, 7646, 11707, 11708, aura = true }, -- Curse of Weakness
        { 440892, 1311676, 1311677, 1311680, aura = true }, -- Curse of the Elements
        { 6789, 17925, 17926, cd = true, aura = true }, -- Death Coil
        { 706, 1086, 11733, 11734, 11735, aura = true }, -- Demon Armor
        { 687, 696, aura = true }, -- Demon Skin
        { 18788, aura = true }, -- Demonic Sacrifice
        { 132, 2970, 11743, aura = true }, -- Detect Invisibility
        { 19505, 19731, 19734, 19736, cd = true }, -- Devour Magic
        { 689, 699, 709, 7651, 11699, 11700, aura = true }, -- Drain Life
        { 5138, 6226, 11703, 11704, aura = true }, -- Drain Mana
        { 1120, 8288, 8289, 11675, aura = true }, -- Drain Soul
        { 5782, 6213, 6215, aura = true }, -- Fear
        { 18708, cd = true }, -- Fel Domination
        { 2947, 8316, 8317, 11770, 11771, aura = true }, -- Fire Shield
        { 755, 3698, 3699, 3700, 11693, 11694, 11695, aura = true }, -- Health Funnel
        { 1949, 11683, 11684, aura = true }, -- Hellfire
        { 5484, 17928, cd = true, aura = true }, -- Howl of Terror
        { 348, 707, 1094, 2941, 11665, 11667, 11668, 25309, aura = true }, -- Immolate
        { 1122, cd = true, aura = true }, -- Inferno
        { 7814, 7815, 7816, 11778, 11779, 11780, cd = true }, -- Lash of Pain
        { 7870, aura = true }, -- Lesser Invisibility
        { 4511, cd = true }, -- Phase Shift
        { 5740, 6219, 11677, 11678, aura = true }, -- Rain of Fire
        { 18540, cd = true }, -- Ritual of Doom
        { 7812, 19438, 19440, 19441, 19442, 19443, aura = true }, -- Sacrifice
        { 6358, aura = true }, -- Seduction
        { 6229, 11739, 11740, 28610, cd = true, aura = true }, -- Shadow Ward
        { 17877, 18867, 18868, 18869, 18870, 18871, cd = true }, -- Shadowburn
        { 18265, 18879, 18880, 18881, aura = true }, -- Siphon Life
        { 6360, 7813, 11784, 11785, cd = true }, -- Soothing Kiss
        { 6353, 17924, cd = true }, -- Soul Fire
        { 19244, 19647, cd = true, aura = true }, -- Spell Lock
        { 17735, 17750, 17751, 17752, cd = true }, -- Suffering
        { 19478, 19655, 19656, 19660, aura = true }, -- Tainted Blood
        { 3716, 7809, 7810, 7811, 11774, 11775, cd = true }, -- Torment
        { 5697, aura = true }, -- Unending Breath
        { 1316697, aura = true }, -- Wrack
    },
    DRUID = {
        { 2893, aura = true }, -- Abolish Poison
        { 22812, cd = true, aura = true }, -- Barkskin
        { 5211, 6798, 8983, cd = true, aura = true }, -- Bash
        { 5209, cd = true, aura = true }, -- Challenging Roar
        { 8998, 9000, 9892, cd = true }, -- Cower
        { 1850, 9821, cd = true, aura = true }, -- Dash
        { 99, 1735, 9490, 9747, 9898, aura = true }, -- Demoralizing Roar
        { 5229, cd = true, aura = true }, -- Enrage
        { 339, 1062, 5195, 5196, 9852, 9853, aura = true }, -- Entangling Roots
        { 770, 778, 9749, 9907, aura = true }, -- Faerie Fire
        { 1238122, cd = true, aura = true }, -- Feral Charge
        { 22842, cd = true, aura = true }, -- Frenzied Regeneration
        { 21849, 21850, aura = true }, -- Gift of the Wild
        { 6795, cd = true }, -- Growl
        { 2637, 18657, 18658, aura = true }, -- Hibernate
        { 16914, 17401, 17402, aura = true }, -- Hurricane
        { 29166, cd = true, aura = true }, -- Innervate
        { 5570, 24974, 24975, 24976, 24977, aura = true }, -- Insect Swarm
        { 1328617, 1328616, 414644, 1235826, 1235827, aura = true }, -- Lacerate
        { 1126, 5232, 6756, 5234, 8907, 9884, 9885, aura = true }, -- Mark of the Wild
        { 8921, 8924, 8925, 8926, 8927, 8928, 8929, 9833, 9834, 9835, aura = true }, -- Moonfire
        { 16689, 16810, 16811, 16812, 16813, 17329, cd = true, aura = true }, -- Nature's Grasp
        { 17116, cd = true }, -- Nature's Swiftness
        { 1328829, aura = true, passive = true }, -- Poised
        { 9005, 9823, 9827, aura = true }, -- Pounce
        { 407995, 1238069, 1238070, cd = true }, -- Primal Bite
        { 5215, 6783, 9913, cd = true }, -- Prowl
        { 1822, 1823, 1824, 9904, aura = true }, -- Rake
        { 20484, 20739, 20742, 20747, 20748, cd = true }, -- Rebirth
        { 8936, 8938, 8939, 8940, 8941, 9750, 9856, 9857, 9858, aura = true }, -- Regrowth
        { 774, 1058, 1430, 2090, 2091, 3627, 8910, 9839, 9840, 9841, 25299, aura = true }, -- Rejuvenation
        { 1079, 9492, 9493, 9752, 9894, 9896, aura = true }, -- Rip
        { 1322605, cd = true }, -- Shifting Power
        { 2908, 8955, 9901, aura = true }, -- Soothe Animal
        { 18562, cd = true }, -- Swiftmend
        { 467, 782, 1075, 8914, 9756, 9910, aura = true }, -- Thorns
        { 740, 8918, 9862, 9863, cd = true, aura = true }, -- Tranquility
        { 408120, 1238214, 1238215, cd = true, aura = true }, -- Wild Growth
    },
    GROUP = {
        { 1243, 1244, 1245, 2791, 10937, 10938, class = "PRIEST" }, -- Power Word: Fortitude
        { 21562, 21564, class = "PRIEST" }, -- Prayer of Fortitude
        { 14752, 14818, 14819, 27841, class = "PRIEST" }, -- Divine Spirit
        { 27681, class = "PRIEST" }, -- Prayer of Spirit
        { 976, 10957, 10958, class = "PRIEST" }, -- Shadow Protection
        { 27683, class = "PRIEST" }, -- Prayer of Shadow Protection
        { 10060, class = "PRIEST" }, -- Power Infusion
        { 6346, class = "PRIEST" }, -- Fear Ward
        { 1126, 5232, 6756, 5234, 8907, 9884, 9885, class = "DRUID" }, -- Mark of the Wild
        { 21849, 21850, class = "DRUID" }, -- Gift of the Wild
        { 467, 782, 1075, 8914, 9756, 9910, class = "DRUID" }, -- Thorns
        { 29166, class = "DRUID" }, -- Innervate
        { 1459, 1460, 1461, 10156, 10157, class = "MAGE" }, -- Arcane Intellect
        { 23028, class = "MAGE" }, -- Arcane Brilliance
        { 1008, 8455, 10169, 10170, class = "MAGE" }, -- Amplify Magic
        { 604, 8450, 8451, 10173, 10174, class = "MAGE" }, -- Dampen Magic
        { 19740, 19834, 19835, 19836, 19837, 19838, 25291, class = "PALADIN" }, -- Blessing of Might
        { 19742, 19850, 19852, 19853, 19854, 25290, class = "PALADIN" }, -- Blessing of Wisdom
        { 20217, class = "PALADIN" }, -- Blessing of Kings
        { 1022, 5599, 10278, class = "PALADIN" }, -- Blessing of Protection
        { 1044, class = "PALADIN" }, -- Blessing of Freedom
        { 25782, 25916, class = "PALADIN" }, -- Greater Blessing of Might
        { 25894, 25918, class = "PALADIN" }, -- Greater Blessing of Wisdom
        { 25898, class = "PALADIN" }, -- Greater Blessing of Kings
    },
}

ns.CdmSpells = S
